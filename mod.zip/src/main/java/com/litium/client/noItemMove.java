package com.litium.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Mouse;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(Side.CLIENT)
public class noItemMove {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void mouseClickEvent(GuiScreenEvent.MouseInputEvent.Pre event) {
        // Проверяем, что текущее GUI является контейнером (например, инвентарь или сундук)
        if (event.getGui() instanceof GuiContainer) {
            Minecraft mc = Minecraft.getMinecraft();
            EntityPlayer player = mc.player;
        if (mc == null || mc.player == null) {
            return;
        }
            boolean noUse = player.getEntityData().getBoolean("noUse");
            if (noUse) {
                System.out.println("Try off");
                event.setCanceled(true);
            }
            }
    }
}
