package com.litium.client.world;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class WorldSelect {
    private final Minecraft mc = Minecraft.getMinecraft();
    public boolean launch = false;
    @SubscribeEvent
    public void onLaunch(GuiOpenEvent event) {
        if (!launch &&
                event.getGui() instanceof GuiMainMenu &&
                mc.world == null) { // Кнопка одиночной игры
            launch = true;
        }
    }
}
