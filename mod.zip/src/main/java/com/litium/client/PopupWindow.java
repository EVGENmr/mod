package com.litium.client;

import net.minecraft.util.text.translation.I18n;

import javax.swing.*;
import java.awt.*;

public class PopupWindow {
    private JFrame frame;
    private String title, sub_title, title_button;
    private int width, height;

    public PopupWindow(String title, String sub_title, String title_button, int width, int height) {
        this.title = title;
        this.sub_title = sub_title;
        this.title_button = title_button;
        this.width = width;
        this.height = height;
        createWindow();
    }

    private void createWindow() {
        frame = new JFrame();
        frame.setTitle(I18n.translateToLocal(title));
        frame.setSize(width, height);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null); // Центрируем на экране
        frame.setLayout(new BorderLayout());

        // Пример содержимого — можно заменить на своё
        JLabel label = new JLabel(I18n.translateToLocal(sub_title), SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(Color.DARK_GRAY);

        JButton closeButton = new JButton(I18n.translateToLocal(title_button));
        closeButton.addActionListener(e -> close());

        frame.add(label, BorderLayout.CENTER);
        frame.add(closeButton, BorderLayout.SOUTH);

        // Дополнительно: закрытие по клавише Escape
        frame.getRootPane().registerKeyboardAction(e -> close(),
                KeyStroke.getKeyStroke("ESCAPE"),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
        show();
    }

    // Показать окно
    public void show() {
        SwingUtilities.invokeLater(() -> {
            if (!frame.isVisible()) {
                frame.setVisible(true);
            }
            frame.toFront();  // Выводим на передний план
            frame.repaint();
        });
    }

    // Закрыть окно
    public void close() {
        frame.dispose(); //, если хотите уничтожить полностью
    }

    // Установить пользовательский контент
    public void setContentPane(JComponent content) {
        SwingUtilities.invokeLater(() -> {
            frame.setContentPane(content);
            frame.validate();
        });
    }

    // Проверка — открыто ли окно
    public boolean isVisible() {
        return frame.isVisible();
    }

    // Получить ссылку на фрейм (для расширения функционала)
    public JFrame getFrame() {
        return frame;
    }
}

