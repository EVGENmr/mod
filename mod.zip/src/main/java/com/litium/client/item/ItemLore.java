package com.litium.client.item;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.translation.I18n;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.List;

@SideOnly(Side.CLIENT)
public class ItemLore {

    @SubscribeEvent
    public void onTooltip(net.minecraftforge.event.entity.player.ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();
        List<String> tooltip = event.getToolTip();

        if (stack.hasTagCompound()) {
            NBTTagCompound nbt = stack.getTagCompound();
            if (nbt.hasKey("display", 10)) {
                NBTTagCompound display = nbt.getCompoundTag("display");
                if (display.hasKey("LocLore", 9)) {
                    NBTTagList locLoreList = display.getTagList("LocLore", 8);
                    if (!locLoreList.hasNoTags()) {
                        // Вставляем в НАЧАЛО тултипа (после названия)
                        int insertIndex = findStartPosition(tooltip);
                        for (int i = 0; i < locLoreList.tagCount(); ++i) {
                            String line = locLoreList.getStringTagAt(i);
                            if (line != null) {
                                String localizedLine = I18n.translateToLocal(line);
                                tooltip.add(insertIndex + i, TextFormatting.DARK_PURPLE + "" + TextFormatting.ITALIC + localizedLine);
                            }
                        }
                    }
                }
            }
        }
    }

    private int findStartPosition(List<String> tooltip) {
        // Вставляем сразу после названия предмета (первая строка)
        return 1;
    }
}