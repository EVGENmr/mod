package com.litium.client;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import org.lwjgl.input.Mouse;

public class CameraHandler {
    public static float offset = 0.6f;
    private static boolean isRightClickDown = false;
    public static int savedPerspective = 0;

    public static void update() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen != null) return;
        EntityPlayer player = mc.player;
        if (player == null) return;
        if (mc.playerController.isSpectator()) {
            mc.gameSettings.thirdPersonView = 0;
            isRightClickDown = false;
            savedPerspective = 0;
            return;
        }
        boolean rightClickHeld = Mouse.isButtonDown(1);

        ItemStack mainHandStack = player.getHeldItemMainhand();
        if (rightClickHeld && hasFireModeNBT(mainHandStack)) {
            if (mc.gameSettings.thirdPersonView == 1) {
                savedPerspective = mc.gameSettings.thirdPersonView;
                mc.gameSettings.thirdPersonView = 0;
                isRightClickDown = true;
            }
        }
        else if (isRightClickDown) {
            if (mc.gameSettings.thirdPersonView == 0) {
                mc.gameSettings.thirdPersonView = savedPerspective;
                isRightClickDown = false;
                savedPerspective = 0;
            }
        }
        }
    // Метод проверки наличия NBT-тега "firemode"
    private static boolean hasFireModeNBT(ItemStack stack) {
        if (stack == null || stack.getItem() == null) return false;
        NBTTagCompound tag = stack.getTagCompound();
        return tag != null && tag.hasKey("firemode");
    }

    }


