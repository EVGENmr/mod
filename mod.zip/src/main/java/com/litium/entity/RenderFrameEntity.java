package com.litium.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class RenderFrameEntity extends EntityLiving {
    private ItemStack heldItem = ItemStack.EMPTY;

    public RenderFrameEntity(World world) {
        super(world);
        this.setSize(0.2f, 0.2f);
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound compound) {
        super.writeEntityToNBT(compound);

        // Сохранение предмета
        if (!heldItem.isEmpty()) {
            compound.setTag("HeldItem", heldItem.writeToNBT(new NBTTagCompound()));
        }
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);

        // Загрузка предмета - правильный способ для 1.12.2
        if (compound.hasKey("HeldItem")) {
            this.heldItem = new ItemStack(compound.getCompoundTag("HeldItem"));
        }

        // Проверка на null/пустой предмет
        if (this.heldItem == null || this.heldItem.isEmpty()) {
            this.heldItem = ItemStack.EMPTY;
        }
    }

    // Методы для работы с предметом
    public void setHeldItem(ItemStack item) {
        this.heldItem = item != null ? item : ItemStack.EMPTY;
    }

    public ItemStack getHeldItem() {
        return this.heldItem;
    }

    public boolean hasHeldItem() {
        return !this.heldItem.isEmpty();
    }
}
