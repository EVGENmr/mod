package com.litium.hud;


import com.litium.common.numberOverlay;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.player.EntityPlayer;

import net.minecraft.client.renderer.GlStateManager;

import net.minecraft.potion.Potion;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.Display;

import java.util.Objects;

import static com.litium.common.ConfigConst.someText;

public class Overlay extends numberOverlay {
    private final Minecraft mc = Minecraft.getMinecraft();
    boolean maskEquped;
    int mask;
    boolean target;
    int energy;
    int cooldown;
    @SubscribeEvent
    public void onOverlayPre(RenderGameOverlayEvent.Pre event) {
        if (event.getType() == RenderGameOverlayEvent.ElementType.ARMOR || event.getType() == RenderGameOverlayEvent.ElementType.AIR || event.getType() == RenderGameOverlayEvent.ElementType.FOOD || event.getType() == RenderGameOverlayEvent.ElementType.HEALTH || event.getType() == RenderGameOverlayEvent.ElementType.EXPERIENCE
        || event.getType() == RenderGameOverlayEvent.ElementType.HEALTHMOUNT || event.getType() == RenderGameOverlayEvent.ElementType.POTION_ICONS) {
            event.setCanceled(true);
        }
    }
    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        if (event.getGui() instanceof net.minecraft.client.gui.GuiMainMenu) {
            Display.setTitle(someText);
        }
    }
    @SubscribeEvent
    public void Render(RenderGameOverlayEvent.Post event) {
        if (event.getType() == RenderGameOverlayEvent.ElementType.ALL) {
            //EntityPlayerSP player = this.mc.player;
            EntityPlayer player = this.mc.player;
            maskEquped = player.getEntityData().getBoolean("maskEquped");
            mask = player.getEntityData().getInteger("mask");
            target = player.getEntityData().getBoolean("target");
            energy = player.getEntityData().getInteger("energy");
            cooldown = player.getEntityData().getInteger("cooldown");

            int w = event.getResolution().getScaledWidth();
            int h = event.getResolution().getScaledHeight();

            if (this.mc.playerController.isSpectator()) {
                return;
            }

            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);

            Minecraft.getMinecraft().renderEngine.bindTexture(new ResourceLocation("litium:textures/util.png"));
            Gui.drawModalRectWithCustomSizedTexture(w / 8, h / 2, 0, 0, 42, 42, 256, 256);
            float Hp = player.getHealth() / player.getMaxHealth();
            if (Hp > 1) {
                Hp = 1;
            }
            int offsetHpY, offsetFoodY, offsetAirY, w1, h1;
            int sizeHealth = 22;

            offsetHpY = (int) Math.round(Hp * 22);
            w1 = (w / 8) + 10;
            h1 = (h / 2) + 10;
            if (player.hurtTime > 0 && player.hurtTime < 3) {
                Gui.drawModalRectWithCustomSizedTexture(w1, h1, 42, sizeHealth, sizeHealth, sizeHealth, 256, 256);
            }
            if (mc.player.isPotionActive(Objects.requireNonNull(Potion.getPotionFromResourceLocation("wither")))) {
                Gui.drawModalRectWithCustomSizedTexture(w1, h1 + sizeHealth - offsetHpY, 108, sizeHealth - offsetHpY, sizeHealth, offsetHpY, 256, 256);
            } else if (mc.player.isPotionActive(Objects.requireNonNull(Potion.getPotionFromResourceLocation("poison")))) {
                Gui.drawModalRectWithCustomSizedTexture(w1, h1 + sizeHealth - offsetHpY, 86, sizeHealth - offsetHpY, sizeHealth, offsetHpY, 256, 256);
            }
            else {
                Gui.drawModalRectWithCustomSizedTexture(w1, h1 + sizeHealth - offsetHpY, 42, sizeHealth - offsetHpY, sizeHealth, offsetHpY, 256, 256);
            }
            if (mc.player.isPotionActive(Objects.requireNonNull(Potion.getPotionFromResourceLocation("absorption")))) {
                if (player.getAbsorptionAmount() > 0) {
                    Hp = player.getAbsorptionAmount() / player.getMaxHealth();
                    if (Hp > 1) {
                        Hp = 1;
                    }
                    offsetHpY = (int) Math.round(Hp * 22);
                    Gui.drawModalRectWithCustomSizedTexture(w1, h1 + sizeHealth - offsetHpY, 64, sizeHealth - offsetHpY, sizeHealth, offsetHpY, 256, 256);
                }
            }

            float Food = (float) player.getFoodStats().getFoodLevel() / 20;

            offsetFoodY = (int) Math.round(Food * 34);
            Gui.drawModalRectWithCustomSizedTexture((w / 8) - 42, (h / 2), 0, 84, 42, 42, 256, 256);
            Gui.drawModalRectWithCustomSizedTexture((w / 8) - 42 + 4, (h / 2) + 34 - offsetFoodY + 4, 42, 88 + 34 - offsetFoodY, 34, offsetFoodY, 256, 256);

            if (player.isInsideOfMaterial(Material.WATER)) {
                float Air = (float) player.getAir() / 300;

                offsetAirY = (int) Math.round(Air * 34);
                Gui.drawModalRectWithCustomSizedTexture((w / 8), (h / 2) - 42, 0, 84, 42, 42, 256, 256);
                Gui.drawModalRectWithCustomSizedTexture((w / 8) + 4, (h / 2) - 42 + 34 - offsetAirY + 4, 42, 130 + 34 - offsetAirY, 34, offsetAirY, 256, 256);
            }
            else {
                Gui.drawModalRectWithCustomSizedTexture((w / 8), (h / 2) - 42, 0, 210, 42, 42, 256, 256);
            }

            Gui.drawModalRectWithCustomSizedTexture((w / 8) - 42, (h / 2) - 42, 0, 42, 42, 42, 256, 256);
            if (target) {
                Gui.drawModalRectWithCustomSizedTexture((w / 8) - 42 + 12, (h / 2) + 12 - 42, 42, 46, 18, 18, 256, 256);
            }

            Gui.drawModalRectWithCustomSizedTexture((w / 8) - 42, (h / 2) - 84, 172, 0, 84, 42, 256, 256);
            float En = (float) energy / 20;
            int offsetEn = (int) Math.round(En * 34);
            Gui.drawModalRectWithCustomSizedTexture((w / 8) - 42 + 6, (h / 2) - 84 + 14, 178, 42, offsetEn, 8, 256, 256);
            bar((w / 8) - 42 + 20, (h / 2) - 84 + 16, energy);

            float Col = (float) cooldown / 60;
            int offsetCol =  (int) Math.round(Col * 34);
            Gui.drawModalRectWithCustomSizedTexture((w / 8) - 42 + 44, (h / 2) - 84 + 14, 216, 42, offsetCol, 8, 256, 256);
            bar((w / 8) - 42 + 58, (h / 2) - 84 + 16, cooldown);

            if (maskEquped) {
                Gui.drawModalRectWithCustomSizedTexture((w / 8), (h / 2) + 42, 0, 168, 42, 42, 256, 256);

                if (mask >= 300) {
                    Gui.drawModalRectWithCustomSizedTexture((w / 8) + 8, (h / 2) + 6 + 42, 43, 172, 26, 18, 256, 256);
                } else if (mask >= 180) {
                    Gui.drawModalRectWithCustomSizedTexture((w / 8) + 8, (h / 2) + 6 + 42, 71, 172, 26, 18, 256, 256);
                } else if (mask >= 120) {
                    Gui.drawModalRectWithCustomSizedTexture((w / 8) + 8, (h / 2) + 6 + 42, 99, 172, 26, 18, 256, 256);
                } else {
                    Gui.drawModalRectWithCustomSizedTexture((w / 8) + 8, (h / 2) + 6 + 42, 127, 172, 26, 18, 256, 256);
                }
                timer((w / 8) + 12, (h / 2) + 42 + 12, mask);
            }
            else {
                Gui.drawModalRectWithCustomSizedTexture((w / 8), (h / 2) + 42, 0, 210, 42, 42, 256, 256);
            }
            Gui.drawModalRectWithCustomSizedTexture((w / 8) - 42, (h / 2) + 42, 0, 210, 42, 42, 256, 256);


            //GlStateManager.depthMask(false);
            //GlStateManager.disableDepth();
            GlStateManager.disableAlpha();
            GlStateManager.disableBlend();
            //GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.popMatrix();
        }
    }

}