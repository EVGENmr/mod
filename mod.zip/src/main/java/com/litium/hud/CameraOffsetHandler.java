package com.litium.hud;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.EntityViewRenderEvent.CameraSetup;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class CameraOffsetHandler {
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Pre event) {
        if (event.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS) {
            if (mc.gameSettings.thirdPersonView == 1) {
                drawCrosshair();
            }
        }
    }
    @SubscribeEvent
    public void onCameraSetup(CameraSetup event) {
        if (mc.gameSettings.thirdPersonView == 1 && this.mc.currentScreen == null) { // Проверяем, что камера в 3-м лице (за спиной)
            EntityPlayer player = mc.player;
            if (player != null && mc.gameSettings.keyBindUseItem.isKeyDown()) { // Если прицеливается
                    // Немного поворачиваем камеру вправо
                    //event.setYaw(event.getYaw() - 15.0F);
            }
        }
    }
    private void drawCrosshair() {
        ScaledResolution res = new ScaledResolution(mc);
        int x = res.getScaledWidth() / 2;
        int y = res.getScaledHeight() / 2;

        mc.getTextureManager().bindTexture(Gui.ICONS);
        GlStateManager.enableBlend();
        mc.ingameGUI.drawTexturedModalRect(x - 7, y - 7, 0, 0, 16, 16);
        GlStateManager.disableBlend();
    }
}
