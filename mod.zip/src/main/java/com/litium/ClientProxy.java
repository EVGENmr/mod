package com.litium;

import com.litium.client.ConfigConst;
import com.litium.client.CubeRenderer;
import com.litium.client.PopupWindow;
import com.litium.client.Window;
import com.litium.client.item.ItemLore;
import com.litium.client.hud.Overlay;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.lwjgl.opengl.Display;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import static com.litium.client.ConfigConst.someText;

public class ClientProxy extends CommonProxy
{
    @Override
    public void preInit(FMLPreInitializationEvent event) throws UnsupportedEncodingException {
        ConfigConst.loadConfig(event);
        Window.setWindowIcon();
        Display.setTitle(new String(someText.getBytes(StandardCharsets.UTF_8)));
        super.preInit(event);
    }

    @Override
    public void init(FMLInitializationEvent event)
    {
        MinecraftForge.EVENT_BUS.register(new Running());
        MinecraftForge.EVENT_BUS.register(new Overlay());
        MinecraftForge.EVENT_BUS.register(new CubeRenderer());
        MinecraftForge.EVENT_BUS.register(new ItemLore());
        super.init(event);
    }

    @Override
    public void postInit(FMLPostInitializationEvent event)
    {
        PopupWindow popup = new PopupWindow("cbf.open", "cbf.runned", "cbf.close", 300, 150);
        //popup.show();
        super.postInit(event);
    }
}
