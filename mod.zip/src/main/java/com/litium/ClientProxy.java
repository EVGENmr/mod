package com.litium;

import com.litium.common.ConfigConst;
import com.litium.common.CubeRenderer;
import com.litium.common.Window;
import com.litium.hud.CameraOffsetHandler;
import com.litium.hud.Overlay;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.lwjgl.opengl.Display;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.*;

import static com.litium.common.ConfigConst.someText;

public class ClientProxy extends CommonProxy
{
    @Override
    public void preInit(FMLPreInitializationEvent event) throws UnsupportedEncodingException {
        ConfigConst.loadConfig(event);
        Window.setWindowIcon();
        Display.setTitle(new String(someText.getBytes("UTF-8")));
        super.preInit(event);
    }

    @Override
    public void init(FMLInitializationEvent event)
    {
        MinecraftForge.EVENT_BUS.register(new Running());
        MinecraftForge.EVENT_BUS.register(new CubeRenderer.NoSpec());
        MinecraftForge.EVENT_BUS.register(new Overlay());
        MinecraftForge.EVENT_BUS.register(new CubeRenderer());
        MinecraftForge.EVENT_BUS.register(new CameraOffsetHandler());

        super.init(event);
    }

    @Override
    public void postInit(FMLPostInitializationEvent event)
    {
        super.postInit(event);
    }
}
