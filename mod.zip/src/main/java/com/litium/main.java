package com.litium;

import com.litium.common.CommandSwitchWorld;
import com.litium.entity.RenderFrameEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;

import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

import java.io.UnsupportedEncodingException;

@Mod(modid = main.MODID, name = main.NAME, version = main.VERSION)

public class main
{

    public static final String MODID = "litium";
    public static final String NAME = "litium core";
    public static final String VERSION = "1.0.3";

    @SidedProxy(clientSide = "com.litium.ClientProxy", serverSide = "com.litium.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void onServerStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandSwitchWorld());
    }

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) throws UnsupportedEncodingException {
        EntityRegistry.registerModEntity(
                new ResourceLocation(MODID, "render_frame"), // ResourceLocation для идентификации
                RenderFrameEntity.class, // Класс сущности
                "render_frame", // Имя сущности
                0, // ID сущности
                this, // Мод-контекст
                64, // Дистанция обновления
                1, // Частота обновления
                true // Отслеживание
        );
        proxy.preInit(event);
    }

    @EventHandler
    public void init(FMLInitializationEvent event)
    {
        proxy.init(event);
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event)
    {
        proxy.postInit(event);
    }

    @EventHandler
    public void serverLoad(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandSwitchWorld());
    }
}

