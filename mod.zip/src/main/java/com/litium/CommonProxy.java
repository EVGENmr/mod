package com.litium;

import com.litium.common.ModNetworkHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

import java.io.UnsupportedEncodingException;

public class CommonProxy {
    public void preInit(FMLPreInitializationEvent event) throws UnsupportedEncodingException {
        ModNetworkHandler.registerMessages();
        MinecraftForge.EVENT_BUS.register(new Synh());

    }

    public void init(FMLInitializationEvent event) {}

    public void postInit(FMLPostInitializationEvent event) {}
}
