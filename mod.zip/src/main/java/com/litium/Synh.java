package com.litium;

import com.litium.common.ModNetworkHandler;
import com.litium.common.PlayerDataSyncPacket;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Synh {

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        if (!event.player.world.isRemote && event.player instanceof EntityPlayerMP) {
            EntityPlayerMP player = (EntityPlayerMP) event.player;

            // Получаем NBT данные игрока
            NBTTagCompound playerData = player.getEntityData();

            // Создаём пакет с NBT данными
            PlayerDataSyncPacket packet = new PlayerDataSyncPacket(playerData);

            // Отправляем пакет только этому игроку
            ModNetworkHandler.INSTANCE.sendTo(packet, player);
        }
    }
}
