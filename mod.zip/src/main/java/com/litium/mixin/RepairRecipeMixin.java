package com.litium.mixin;

// RepairRecipeMixin.java
import net.minecraft.item.crafting.RecipeRepairItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;

@Mixin(RecipeRepairItem.class)
public class RepairRecipeMixin {

    @Inject(method = "matches", at = @At("HEAD"), cancellable = true)
    private void onMatches(InventoryCrafting inv, net.minecraft.world.World world,
                           CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
        cir.cancel();
    }

    @Inject(method = "getCraftingResult", at = @At("HEAD"), cancellable = true)
    private void onGetCraftingResult(InventoryCrafting inventory, CallbackInfoReturnable<ItemStack> cir) {
        cir.setReturnValue(ItemStack.EMPTY);
        cir.cancel();
    }
}
