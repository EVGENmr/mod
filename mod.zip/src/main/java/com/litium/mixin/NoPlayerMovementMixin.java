package com.litium.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.MoverType;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityPlayerSP.class)
public abstract class NoPlayerMovementMixin {

    private final Minecraft mc = Minecraft.getMinecraft();
    @Inject(method = "move", at = @At("HEAD"), cancellable = true)
    private void onMove(MoverType type, double x, double y, double z, CallbackInfo ci) {
        EntityPlayer player = this.mc.player;
        if (player == null) return;
        boolean stopped = player.getEntityData().getBoolean("stopped");
        if (stopped) {
            ci.cancel();  // Отменяем движение
        }
    }
}
