package com.litium.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = ContainerPlayer.class, remap = false)
public class NoItemtransfer  {

    @Inject(
            method = "transferStackInSlot",
            at = @At("HEAD"),
            cancellable = true
    )
    private void preventItemTransfer(EntityPlayer p_82846_1_, int p_82846_2_, CallbackInfoReturnable<ItemStack> cir) {
        // Отменяем операцию перекладывания
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = mc.player;
        boolean noUse = player.getEntityData().getBoolean("noUse");
        if (noUse) {
            //cir.setReturnValue(ItemStack.EMPTY);
            cir.cancel();
        }
    }
}