package com.litium.mixin;

import com.litium.client.CameraHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {

    @Inject(method = "renderWorldPass", at = @At("HEAD"))
    private void onRenderWorldPass(int pass, float partialTicks, long finishTimeNano, CallbackInfo ci) {
        CameraHandler.update();
    }

    @Inject(method = "orientCamera", at = @At("RETURN"))
    private void onOrientCamera(float partialTicks, CallbackInfo ci) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.thirdPersonView != 1 || mc.player == null) return;

        EntityPlayerSP player = mc.player;
        World world = player.world;

        float yaw = mc.getRenderViewEntity().rotationYaw;
        float rightYaw = yaw; //+ 90.0f;

        float safeOffset = calculateSafeOffset(world, player, rightYaw);

        if (safeOffset != 0) {
            float rad = (float)Math.toRadians(rightYaw);
            float dx = (float)Math.cos(rad) * safeOffset;
            float dz = (float)Math.sin(rad) * safeOffset;

            GlStateManager.translate(dx, 0.0f, dz);
        }
    }

    private float calculateSafeOffset(World world, EntityPlayer player, float directionYaw) {
        float maxOffset = CameraHandler.offset;
        float step = 0.1f;
        float currentOffset = 0;

        for (float offset = step; offset <= maxOffset; offset += step) {
            if (!isPathClear(world, player, directionYaw, offset)) {
                return currentOffset;
            }
            currentOffset = offset;
        }

        return maxOffset;
    }

    private boolean isPathClear(World world, EntityPlayer player, float directionYaw, float distance) {
        float[] heightChecks = {0.2f, 0.7f, 1.2f, 1.7f};

        float rad = (float)Math.toRadians(directionYaw);
        double dx = Math.cos(rad) * distance;
        double dz = Math.sin(rad) * distance;

        for (float yOffset : heightChecks) {
            Vec3d startPos = player.getPositionVector().addVector(0.0, yOffset, 0.0);
            Vec3d endPos = startPos.addVector(dx, 0.0, dz);  // Используем addVector

            RayTraceResult result = world.rayTraceBlocks(
                    startPos,
                    endPos,
                    false, true, false
            );

            if (result != null && result.typeOfHit == RayTraceResult.Type.BLOCK) {
                double blockDistance = startPos.distanceTo(result.hitVec);
                if (blockDistance < distance - 0.3) {
                    return false;
                }
            }
        }

        return true;
    }
}