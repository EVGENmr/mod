package com.litium.mixin;

import com.litium.common.CameraHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {

    @Inject(method = "renderWorldPass", at = @At("HEAD"))
    private void onRenderWorldPass(int pass, float partialTicks, long finishTimeNano, CallbackInfo ci) {
        // Обновляем значение смещения
        CameraHandler.update();
    }

    @Inject(method = "orientCamera", at = @At("RETURN"))
    private void onOrientCamera(float partialTicks, CallbackInfo ci) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.thirdPersonView != 1 || mc.player == null) return;
        if (CameraHandler.offset <= 0.001f) return;

        EntityPlayerSP player = mc.player;
        float yaw = mc.getRenderViewEntity().rotationYaw;
        float rad = (float)Math.toRadians(yaw);
        float dx = - (float)Math.sin(rad) * CameraHandler.offset;
        float dz =   (float)Math.cos(rad) * CameraHandler.offset;

        GlStateManager.translate(dx, 0.0f, dz);
    }
}
