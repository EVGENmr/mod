package com.litium.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(InventoryPlayer.class)
public class NewInv {

    @Shadow
    public int currentItem;
    @Shadow
    public NonNullList<ItemStack> mainInventory;

    @Inject(method = "changeCurrentItem", at = @At("HEAD"), cancellable = true)
    @SideOnly(Side.CLIENT)
    public void onChangeCurrentItem(int direction, CallbackInfo ci) {

        Minecraft mc = Minecraft.getMinecraft();

        EntityPlayer player = mc.player;
        boolean noUse = player.getEntityData().getBoolean("noUse");
        if (noUse) {
            ci.cancel(); // Отменяем выполнение оригинальной логики
        }
    }

}
