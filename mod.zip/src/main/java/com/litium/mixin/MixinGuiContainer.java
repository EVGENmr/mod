package com.litium.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.inventory.GuiContainer;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;

import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

import static net.minecraftforge.fml.client.config.GuiUtils.drawTexturedModalRect;

@Mixin(GuiContainer.class)
public class MixinGuiContainer {

    @Inject(
            method = "drawSlot",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/RenderItem;renderItemAndEffectIntoGUI(Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;II)V",
                    shift = At.Shift.BEFORE
            )
    )
    private void drawColoredSlot(Slot slot, CallbackInfo ci) {
        ItemStack stack = slot.getStack();

        if (!stack.isEmpty() && stack.hasTagCompound()) {
            NBTTagCompound nbt = stack.getTagCompound();
            int rareValue = nbt.getInteger("Rare");

            int color;

            switch (rareValue) {
                case 1: color = 0x8800FF00; break; // лайм
                case 2: color = 0x880000FF; break; // синий
                case 3: color = 0x88AA00AA; break; // фиолет
                case 4: color = 0x88FF0000; break; // красный
                case 5: color = 0x88FFFF00; break; // жёлтый
                default: color = 0x00000000; break;
            }

            if (color != 0x00000000) {
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableBlend();
                Gui.drawRect(slot.xPos, slot.yPos, slot.xPos + 16, slot.yPos + 16, color);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                GlStateManager.enableBlend();
            }
        }
    }
}
