package com.litium.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import org.apache.commons.io.IOUtils;
import org.lwjgl.opengl.Display;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(Minecraft.class)
public class NoClick {

    @Inject(method = "processKeyBinds", at = @At("HEAD"), cancellable = true)
    private void cancelHotbar(CallbackInfo ci) {
        Minecraft mc = Minecraft.getMinecraft();

        EntityPlayer player = mc.player;
        boolean noUse = player.getEntityData().getBoolean("noUse");
        if (noUse) {
            for (int i = 0; i < 9; ++i)
            {
                if (mc.gameSettings.keyBindsHotbar[i].isPressed())
                {
                    //ci.cancel();
                    return;
                }
            }
        }
    }
    @Inject(method = "clickMouse", at = @At("HEAD"), cancellable = true)
    private void cancelLeftClick(CallbackInfo ci) {
        Minecraft mc = Minecraft.getMinecraft();

        EntityPlayer player = mc.player;
        boolean noUse = player.getEntityData().getBoolean("noUse");
        if (noUse) {
            ci.cancel();
        }
    }
    @Inject(method = "rightClickMouse", at = @At("HEAD"), cancellable = true)
    private void cancelRightClick(CallbackInfo ci) {
        Minecraft mc = Minecraft.getMinecraft();

        EntityPlayer player = mc.player;
        boolean noUse = player.getEntityData().getBoolean("noUse");
        if (noUse) {
            ci.cancel();
        }
    }



}
