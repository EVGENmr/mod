package com.litium.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import javax.annotation.Nullable;

@Mixin(RenderItem.class)
public class MixinRenderItem {
    private void draw(BufferBuilder p_181565_1_, int p_181565_2_, int p_181565_3_, int p_181565_4_, int p_181565_5_, int p_181565_6_, int p_181565_7_, int p_181565_8_, int p_181565_9_) {
        p_181565_1_.begin(7, DefaultVertexFormats.POSITION_COLOR);
        p_181565_1_.pos((double)(p_181565_2_ + 0), (double)(p_181565_3_ + 0), 0.0).color(p_181565_6_, p_181565_7_, p_181565_8_, p_181565_9_).endVertex();
        p_181565_1_.pos((double)(p_181565_2_ + 0), (double)(p_181565_3_ + p_181565_5_), 0.0).color(p_181565_6_, p_181565_7_, p_181565_8_, p_181565_9_).endVertex();
        p_181565_1_.pos((double)(p_181565_2_ + p_181565_4_), (double)(p_181565_3_ + p_181565_5_), 0.0).color(p_181565_6_, p_181565_7_, p_181565_8_, p_181565_9_).endVertex();
        p_181565_1_.pos((double)(p_181565_2_ + p_181565_4_), (double)(p_181565_3_ + 0), 0.0).color(p_181565_6_, p_181565_7_, p_181565_8_, p_181565_9_).endVertex();
        Tessellator.getInstance().draw();
    }
    /**
     * @author
     * @reason
     */
    @Overwrite
    public void renderItemOverlayIntoGUI(FontRenderer p_180453_1_, ItemStack p_180453_2_, int p_180453_3_, int p_180453_4_, @Nullable String p_180453_5_) {
        if (!p_180453_2_.isEmpty()) {
            NBTTagCompound nbt = p_180453_2_.getTagCompound();
            if (p_180453_2_.getItem().showDurabilityBar(p_180453_2_)) {
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableTexture2D();
                GlStateManager.disableAlpha();
                GlStateManager.disableBlend();
                Tessellator tessellator = Tessellator.getInstance();
                BufferBuilder bufferbuilder = tessellator.getBuffer();
                double health = p_180453_2_.getItem().getDurabilityForDisplay(p_180453_2_);
                int rgbfordisplay = p_180453_2_.getItem().getRGBDurabilityForDisplay(p_180453_2_);
                int i = Math.round(13.0F - (float) health * 13.0F);
                int j = rgbfordisplay;
                this.draw(bufferbuilder, p_180453_3_ + 2, p_180453_4_ + 13, 13, 2, 0, 0, 0, 255);
                this.draw(bufferbuilder, p_180453_3_ + 2, p_180453_4_ + 13, i, 1, j >> 16 & 255, j >> 8 & 255, j & 255, 255);
                GlStateManager.enableBlend();
                GlStateManager.enableAlpha();
                GlStateManager.enableTexture2D();
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
            } else if (nbt != null && nbt.hasKey("Use") && nbt.hasKey("maxUse")) {
                GlStateManager.enableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableTexture2D();
                GlStateManager.disableAlpha();
                GlStateManager.disableBlend();
                Tessellator tessellator = Tessellator.getInstance();
                BufferBuilder bufferbuilder = tessellator.getBuffer();
                double health = (double) nbt.getInteger("Use") / (double) nbt.getInteger("maxUse");
                int i = Math.round(13.0F - (float) health * 13.0F);
                this.draw(bufferbuilder, p_180453_3_ + 2, p_180453_4_ + 13, 13, 2, 0, 0, 0, 255);
                this.draw(bufferbuilder, p_180453_3_ + 2, p_180453_4_ + 13, i, 1, 140, 93, 94, 255);
                GlStateManager.enableBlend();
                GlStateManager.enableAlpha();
                GlStateManager.enableTexture2D();
                GlStateManager.disableLighting();
                GlStateManager.enableDepth();
            }
            if (p_180453_2_.getCount() != 1 || p_180453_5_ != null) {
                String s = p_180453_5_ == null ? String.valueOf(p_180453_2_.getCount()) : p_180453_5_;
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableBlend();
                p_180453_1_.drawStringWithShadow(s, (float) (p_180453_3_ + 19 - 2 - p_180453_1_.getStringWidth(s)), (float) (p_180453_4_ + 6 + 3), 16777215);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                GlStateManager.enableBlend();
            }

            if (nbt != null && nbt.hasKey("Type")) {
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableBlend();
                Minecraft.getMinecraft().renderEngine.bindTexture(new ResourceLocation("litium:textures/type.png"));
                String Type = p_180453_2_.getTagCompound().getString("Type");
                float x = 0,y = 0;
                switch (Type) {
                    case "food": x = 0; y = 6; break; // лайм
                    case "heal": x = 6; y = 6; break; // синий
                    case "buff": x = 0; y = 0; break; // фиолет
                    case "weapon": x = 6; y = 0; break; // красный
                    default: break;
                }
                Gui.drawModalRectWithCustomSizedTexture(p_180453_3_ + 10, p_180453_4_, x, y, 6, 6, 16, 16);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                GlStateManager.enableBlend();
            }

            EntityPlayerSP entityplayersp = Minecraft.getMinecraft().player;
            float f3 = entityplayersp == null ? 0.0F : entityplayersp.getCooldownTracker().getCooldown(p_180453_2_.getItem(), Minecraft.getMinecraft().getRenderPartialTicks());
            if (f3 > 0.0F) {
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableTexture2D();
                Tessellator tessellator1 = Tessellator.getInstance();
                BufferBuilder bufferbuilder1 = tessellator1.getBuffer();
                this.draw(bufferbuilder1, p_180453_3_, p_180453_4_ + MathHelper.floor(16.0F * (1.0F - f3)), 16, MathHelper.ceil(16.0F * f3), 255, 255, 255, 127);
                GlStateManager.enableTexture2D();
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
            }
        }

    }
}
