package com.litium.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.lang.reflect.Field;

@Mixin(KeyBinding.class)
public class MixinKeyBinding {

    @Inject(method = "isKeyDown", at = @At("HEAD"), cancellable = true)
    private void onIsKeyDown(CallbackInfoReturnable<Boolean> cir) {
        // Проверим, что это именно клавиша "движение вперёд"
        KeyBinding self = (KeyBinding)(Object)this;
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = mc.player;
        if (player == null) {return;}
        if (mc.currentScreen != null) {
            return;
        }
        boolean stunned = player.getEntityData().getBoolean("stunned");
        boolean noUse = player.getEntityData().getBoolean("noUse");
        if (stunned) {
        if (self == mc.gameSettings.keyBindForward || self == mc.gameSettings.keyBindBack
                || self == mc.gameSettings.keyBindLeft || self == mc.gameSettings.keyBindRight
                || self == mc.gameSettings.keyBindSprint || self == mc.gameSettings.keyBindJump
                || self == mc.gameSettings.keyBindSneak) {
            cir.setReturnValue(false); // Притворимся, что клавиша не нажата
        }
        }

        /*if (noUse) {
            if (self == mc.gameSettings.keyBindAttack || self == mc.gameSettings.keyBindUseItem
            || self == mc.gameSettings.keyBindSwapHands || self == mc.gameSettings.keyBindDrop
            || self == mc.gameSettings.keyBindPickBlock || self == mc.gameSettings.keyBindsHotbar[0]
            || self == mc.gameSettings.keyBindsHotbar[1] || self == mc.gameSettings.keyBindsHotbar[2]
                    || self == mc.gameSettings.keyBindsHotbar[3] || self == mc.gameSettings.keyBindsHotbar[4]
                    || self == mc.gameSettings.keyBindsHotbar[5] || self == mc.gameSettings.keyBindsHotbar[6]
                    || self == mc.gameSettings.keyBindsHotbar[7] || self == mc.gameSettings.keyBindsHotbar[8]) {
                cir.setReturnValue(false); // Притворимся, что клавиша не нажата
            }
        }*/
    }
}
