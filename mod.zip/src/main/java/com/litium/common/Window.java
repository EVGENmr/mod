package com.litium.common;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;

import org.apache.commons.io.IOUtils;
import org.lwjgl.opengl.Display;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

import static com.litium.common.ConfigConst.someText;
import static com.litium.main.MODID;

public class Window {
    public static ResourceLocation image = new ResourceLocation(MODID, "textures/icon.png");

    public static void setWindowIcon() {
        Util.EnumOS util$enumos = Util.getOSType();
        System.out.println(image);
        System.out.println("Litium: display is loading.");
        if (util$enumos != Util.EnumOS.OSX) {
            InputStream inputstream = null;
            InputStream inputstream1 = null;

            try {
                Minecraft mc = Minecraft.getMinecraft();

                inputstream = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(MODID, "textures/icon_16x16.png")).getInputStream();
                inputstream1 = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(MODID, "textures/icon_32x32.png")).getInputStream();
                if (inputstream != null && inputstream1 != null) {
                    Display.setIcon(new ByteBuffer[]{readImageToBuffer(inputstream), readImageToBuffer(inputstream1)});
                    System.out.println("Litium: display is readed.");
                }
            } catch (IOException var8) {
                var8.printStackTrace();
                System.out.println("Litium: display is error.");
                //LOGGER.error("Couldn't set icon", ioexception);
            } finally {
                IOUtils.closeQuietly(inputstream);
                IOUtils.closeQuietly(inputstream1);
            }
        }

    }
    private static ByteBuffer readImageToBuffer(InputStream p_152340_1_) throws IOException {
        BufferedImage bufferedimage = ImageIO.read(p_152340_1_);
        int[] aint = bufferedimage.getRGB(0, 0, bufferedimage.getWidth(), bufferedimage.getHeight(), (int[])null, 0, bufferedimage.getWidth());
        ByteBuffer bytebuffer = ByteBuffer.allocate(4 * aint.length);
        int[] var5 = aint;
        int var6 = aint.length;

        for(int var7 = 0; var7 < var6; ++var7) {
            int i = var5[var7];
            bytebuffer.putInt(i << 8 | i >> 24 & 255);
        }

        bytebuffer.flip();
        return bytebuffer;
    }
}
