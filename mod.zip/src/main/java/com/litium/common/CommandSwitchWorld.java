package com.litium.common;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class CommandSwitchWorld extends CommandBase {
    Minecraft mc = Minecraft.getMinecraft();
    @Override
    public String getName() {
        return "switchworld";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/switchworld";
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
        if (!server.isSinglePlayer()) {
            sender.sendMessage(new TextComponentString(TextFormatting.RED + "Эта команда работает только в одиночной игре"));
            return;
        }

        if (sender instanceof EntityPlayerMP) {
            EntityPlayerMP player = (EntityPlayerMP) sender;

            sender.sendMessage(new TextComponentString(TextFormatting.YELLOW + "Переключаемся на мир 'Проклятье чёрного тумана'..."));

            // Отправляем пакет на клиент
            ModNetworkHandler.INSTANCE.sendTo(new SwitchWorldMessage(), player);
        }
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }

}
