package com.litium.common;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldInfo;
import net.minecraft.world.storage.WorldSummary;
import net.minecraftforge.fml.client.FMLClientHandler;

import javax.annotation.Nullable;
import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class CommandSwitchWorld extends CommandBase {

    public String getName() {
        return "switchworld";
    }

    public String getUsage(ICommandSender sender) {
        return "/switchworld <отображаемое_имя_мира> <папка_мира>";
    }

    public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
        if (!server.isSinglePlayer()) {
            sender.sendMessage(new TextComponentString("§cЭта команда работает только в одиночной игре!"));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(new TextComponentString("§cУкажите отображаемое имя мира и имя папки мира!"));
            return;
        }

        // Первый аргумент — отображаемое имя мира
        String displayName = args[0];
        // Второй аргумент — имя папки с миром
        String worldFolderName = args[1];

        // Получаем папку с сохранёнными мирами
        File savesFolder = new File(Minecraft.getMinecraft().mcDataDir, "saves");
        File worldFolder = new File(savesFolder, worldFolderName);

        if (!worldFolder.exists() || !worldFolder.isDirectory()) {
            sender.sendMessage(new TextComponentString("§cМир с таким названием не найден!"));
            return;
        }

        sender.sendMessage(new TextComponentString("§aВыход из текущего мира..."));

        Minecraft mc = Minecraft.getMinecraft();


            // Выгружаем текущий мир
            mc.world.sendQuittingDisconnectingPacket();
            mc.loadWorld(null);
            mc.displayGuiScreen(new GuiMainMenu());
            //mc.loadWorld(null);

            // Запускаем таймер для задержки перед загрузкой нового мира
          /**  new Timer().schedule(new TimerTask() {

                public void run() {
                    // Возвращаемся на главный поток для запуска интегрированного сервера
                    mc.addScheduledTask(() -> {
                        WorldInfo worldInfo = mc.getSaveLoader().getWorldInfo(worldFolderName);
                        if (worldInfo != null) {
                            mc.launchIntegratedServer(worldFolderName, displayName, null);
                        } else {
                            sender.sendMessage(new TextComponentString("§cНе удалось получить информацию о мире!"));
                        }
                    });
                }
            }, 1500); // задержка 1500 мс (1.5 секунды)
           */

    }


    public int getRequiredPermissionLevel() {
        return 0; // Команда доступна всем игрокам
    }


    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, @Nullable net.minecraft.util.math.BlockPos targetPos) {
        if (args.length == 2) {
            File savesFolder = new File(Minecraft.getMinecraft().mcDataDir, "saves");
            if (savesFolder.exists() && savesFolder.isDirectory()) {
                return getListOfStringsMatchingLastWord(args, savesFolder.list());
            }
        }
        return Collections.emptyList();
    }
}
