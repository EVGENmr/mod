package com.litium.common;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Mouse;

public class CameraHandler {
    public static float offset = 0.0f;
    private static final float MAX_OFFSET = 0.6f;
    private static final float SPEED = 0.05f;

    public static void update() {
        if (Minecraft.getMinecraft().currentScreen != null) return;

        boolean rightClickHeld = Mouse.isButtonDown(1);

        if (rightClickHeld) {
            offset = Math.min(MAX_OFFSET, offset + SPEED);
        } else {
            offset = Math.max(0.0f, offset - SPEED);
        }
    }
}
