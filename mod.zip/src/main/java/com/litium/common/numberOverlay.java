package com.litium.common;

import net.minecraft.client.gui.Gui;

public class numberOverlay {

    public void one (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 174, 54, 3, 5, 256, 256);
    }
    public void two (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 178, 54, 3, 5, 256, 256);
    }
    public void three (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 182, 54, 3, 5, 256, 256);
    }
    public void four (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 186, 54, 3, 5, 256, 256);
    }
    public void five (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 190, 54, 3, 5, 256, 256);
    }
    public void six (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 194, 54, 3, 5, 256, 256);
    }
    public void seven (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 198, 54, 3, 5, 256, 256);
    }
    public void eight (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 202, 54, 3, 5, 256, 256);
    }
    public void nine (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 206, 54, 3, 5, 256, 256);
    }
    public void zero (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 210, 54, 3, 5, 256, 256);
    }
    public void colon (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 214, 54, 3, 5, 256, 256);
    }
    public void slash (int x, int y) {
        Gui.drawModalRectWithCustomSizedTexture(x, y, 214, 54, 3, 5, 256, 256);
    }
    public void bar (int x, int y, int count) {
        int x1 = x + 4;

        if (count > 99) {
            count = 99;
        }

        int decade_count = count / 10;
        switch (decade_count){
            case 1 : one(x, y); break;
            case 2 : two(x, y); break;
            case 3 : three(x, y); break;
            case 4 : four(x, y); break;
            case 5 : five(x, y); break;
            case 6 : six(x, y); break;
            case 7 : seven(x, y); break;
            case 8 : eight(x, y); break;
            case 9 : nine(x, y); break;
            default : zero(x, y);
        }
        int total_count = count - (10 * decade_count);
        switch (total_count){
            case 1 : one(x1, y); break;
            case 2 : two(x1, y); break;
            case 3 : three(x1, y); break;
            case 4 : four(x1, y); break;
            case 5 : five(x1, y); break;
            case 6 : six(x1, y); break;
            case 7 : seven(x1, y); break;
            case 8 : eight(x1, y); break;
            case 9 : nine(x1, y); break;
            default : zero(x1, y);
        }
    }
    public void timer (int x, int y, int time) {
        int x1 = x + 4;
        int x2 = x1 + 4;
        int x3 = x2 + 4;
        int x4 = x3 + 4;

        if (time < 0) {
            time = 0;
        }
        if (time > 1200) {
            time = 1200;
        }

        int min = time / 60;
        if (min > 20) {
            min = 20;
        }

        colon(x2, y);

        int decade_min = min / 10;
        switch (decade_min){
            case 1 : one(x, y); break;
            case 2 : two(x, y); break;
            default : zero(x, y);
        }
        int total_min = min - (10 * decade_min);
        switch (total_min){
            case 1 : one(x1, y); break;
            case 2 : two(x1, y); break;
            case 3 : three(x1, y); break;
            case 4 : four(x1, y); break;
            case 5 : five(x1, y); break;
            case 6 : six(x1, y); break;
            case 7 : seven(x1, y); break;
            case 8 : eight(x1, y); break;
            case 9 : nine(x1, y); break;
            default : zero(x1, y);
        }

        int sec = time % 60;
        if (sec > 59) {
            sec = 59;
        }

        int decade_sec = sec / 10;
        switch (decade_sec){
            case 1 : one(x3, y); break;
            case 2 : two(x3, y); break;
            case 3 : three(x3, y); break;
            case 4 : four(x3, y); break;
            case 5 : five(x3, y); break;
            default : zero(x3, y);
        }
        int total_sec = sec - (10 * decade_sec);
        switch (total_sec){
            case 1 : one(x4, y); break;
            case 2 : two(x4, y); break;
            case 3 : three(x4, y); break;
            case 4 : four(x4, y); break;
            case 5 : five(x4, y); break;
            case 6 : six(x4, y); break;
            case 7 : seven(x4, y); break;
            case 8 : eight(x4, y); break;
            case 9 : nine(x4, y); break;
            default : zero(x4, y);
        }
    }
}
