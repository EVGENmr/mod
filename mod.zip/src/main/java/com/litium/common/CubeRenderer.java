package com.litium.common;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;

import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

import java.util.Objects;


public class CubeRenderer {
    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = mc.player;

        if (player == null || mc.world == null) return;
        if (!mc.player.isPotionActive(Objects.requireNonNull(Potion.getPotionFromResourceLocation("blindness")))) {
        return;
        }
        // Размер куба (радиус от игрока)
        double size = 15.0;

        // Координаты игрока с интерполяцией
        double px = player.lastTickPosX + (player.posX - player.lastTickPosX) * event.getPartialTicks();
        double py = player.lastTickPosY + (player.posY - player.lastTickPosY) * event.getPartialTicks();
        double pz = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * event.getPartialTicks();

        // Смещение камеры
        double camX = mc.getRenderManager().viewerPosX;
        double camY = mc.getRenderManager().viewerPosY;
        double camZ = mc.getRenderManager().viewerPosZ;

        double minX = px - size / 2 - camX;
        double maxX = px + size / 2 - camX;
        double minY = py - size / 2 - camY;
        double maxY = py + size / 2 - camY;
        double minZ = pz - size / 2 - camZ;
        double maxZ = pz + size / 2 - camZ;

        // === ОТРИСОВКА ТОЛЬКО СНАРУЖИ ===
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableCull(); // Отключаем отсечение граней
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.color(0, 0, 0, 1); // Полностью чёрный цвет

        GlStateManager.depthMask(false); // НЕ затираем глубину → блоки внутри видны

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        buffer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION);

        // Верхняя грань
        buffer.pos(minX, maxY, minZ).endVertex();
        buffer.pos(maxX, maxY, minZ).endVertex();
        buffer.pos(maxX, maxY, maxZ).endVertex();
        buffer.pos(minX, maxY, maxZ).endVertex();

        // Нижняя грань
        buffer.pos(minX, minY, minZ).endVertex();
        buffer.pos(minX, minY, maxZ).endVertex();
        buffer.pos(maxX, minY, maxZ).endVertex();
        buffer.pos(maxX, minY, minZ).endVertex();

        // Передняя грань
        buffer.pos(minX, minY, maxZ).endVertex();
        buffer.pos(minX, maxY, maxZ).endVertex();
        buffer.pos(maxX, maxY, maxZ).endVertex();
        buffer.pos(maxX, minY, maxZ).endVertex();

        // Задняя грань
        buffer.pos(minX, minY, minZ).endVertex();
        buffer.pos(maxX, minY, minZ).endVertex();
        buffer.pos(maxX, maxY, minZ).endVertex();
        buffer.pos(minX, maxY, minZ).endVertex();

        // Левая грань
        buffer.pos(minX, minY, minZ).endVertex();
        buffer.pos(minX, maxY, minZ).endVertex();
        buffer.pos(minX, maxY, maxZ).endVertex();
        buffer.pos(minX, minY, maxZ).endVertex();

        // Правая грань
        buffer.pos(maxX, minY, minZ).endVertex();
        buffer.pos(maxX, minY, maxZ).endVertex();
        buffer.pos(maxX, maxY, maxZ).endVertex();
        buffer.pos(maxX, maxY, minZ).endVertex();

        tessellator.draw();

        // Восстанавливаем OpenGL
        GlStateManager.depthMask(true); // Включаем обратно, чтобы мир рендерился нормально

        GlStateManager.enableTexture2D();
        GlStateManager.enableCull();
        GlStateManager.popMatrix();
    }

    public static class NoSpec {
        private final Minecraft mc = Minecraft.getMinecraft();

        @SubscribeEvent
        public void onKeyInput(TickEvent.PlayerTickEvent event) {
            if (mc.player != null) {
                int key;
                boolean stopped = mc.player.getEntityData().getBoolean("stopped");
                if (stopped || mc.player.isSpectator() && this.mc.currentScreen != null) {
                    try {
                        key = mc.gameSettings.keyBindAttack.getKeyCode();
                        if (Keyboard.isKeyDown(key)) {
                            KeyBinding.setKeyBindState(key, false);
                        }} catch (Exception e) {}
                    try {
                    if (Keyboard.isKeyDown(mc.gameSettings.keyBindUseItem.getKeyCode())) {
                        key = mc.gameSettings.keyBindUseItem.getKeyCode();
                        KeyBinding.setKeyBindState(key, false);
                    }} catch (Exception e) {}
                    try {
                    if (Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode())) {
                        key = mc.gameSettings.keyBindJump.getKeyCode();
                        KeyBinding.setKeyBindState(key, false);
                    }} catch (Exception e) {}
                    try {
                    if (Keyboard.isKeyDown(mc.gameSettings.keyBindSwapHands.getKeyCode())) {
                        key = mc.gameSettings.keyBindSwapHands.getKeyCode();
                        KeyBinding.setKeyBindState(key, false);
                    }} catch (Exception e) {}
                    try {
                    if (Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode())) {
                        key = mc.gameSettings.keyBindForward.getKeyCode();
                        KeyBinding.setKeyBindState(key, false);
                    }} catch (Exception e) {}
                    try {
                    if (Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode())) {
                        key = mc.gameSettings.keyBindBack.getKeyCode();
                        KeyBinding.setKeyBindState(key, false);
                    }} catch (Exception e) {}
                    try {
                    if (Keyboard.isKeyDown(mc.gameSettings.keyBindLeft.getKeyCode())) {
                        key = mc.gameSettings.keyBindLeft.getKeyCode();
                        KeyBinding.setKeyBindState(key, false);
                    }} catch (Exception e) {}
                    try {
                    if (Keyboard.isKeyDown(mc.gameSettings.keyBindRight.getKeyCode())) {
                        key = mc.gameSettings.keyBindRight.getKeyCode();
                        KeyBinding.setKeyBindState(key, false);
                    }} catch (Exception e) {}

                }
            }
        }
    }
}









