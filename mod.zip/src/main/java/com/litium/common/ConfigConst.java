package com.litium.common;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import static com.litium.main.MODID;

public class ConfigConst {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static File configFile;

    // Настройки
    public static boolean enableFeature = true;
    public static int someValue = 10;
    public static String someText = "The curse black of te mist";

    public static void loadConfig(FMLPreInitializationEvent event) {
        // Создаём папку, если её нет
        File configDir = new File(event.getModConfigurationDirectory(), MODID);
        if (!configDir.exists()) {
            configDir.mkdirs();
        }

        // Файл конфига
        configFile = new File(configDir, "gui_config.json");

        if (configFile.exists()) {
            readConfig();
        } else {
            saveConfig(); // Создаёт файл с дефолтными значениями
        }
    }

    public static void readConfig() {
        try {
            FileReader reader = new FileReader(configFile);
            JsonParser parser = new JsonParser();

            JsonObject json = parser.parse(reader).getAsJsonObject();

            enableFeature = json.has("enableFeature") ? json.get("enableFeature").getAsBoolean() : enableFeature;
            someValue = json.has("someValue") ? json.get("someValue").getAsInt() : someValue;
            someText = json.has("someText") ? json.get("someText").getAsString() : someText;

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Ошибка чтения конфига!");
        }
    }

    public static void saveConfig() {
        JsonObject json = new JsonObject();
        json.addProperty("enableFeature", enableFeature);
        json.addProperty("someValue", someValue);
        json.addProperty("someText", someText);

        try (FileWriter writer = new FileWriter(configFile)) {
            GSON.toJson(json, writer);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Ошибка сохранения конфига!");
        }
    }
}
