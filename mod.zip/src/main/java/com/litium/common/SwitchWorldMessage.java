package com.litium.common;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class SwitchWorldMessage implements IMessage {

    public SwitchWorldMessage() {}

    @Override
    public void fromBytes(ByteBuf buf) {
        // Пустое, данные не передаем
    }

    @Override
    public void toBytes(ByteBuf buf) {
        // Пустое, данные не передаем
    }

    public static class Handler implements IMessageHandler<SwitchWorldMessage, IMessage> {

        @Override
        @SideOnly(Side.CLIENT)
        public IMessage onMessage(SwitchWorldMessage message, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> {
                performWorldSwitch();
            });
            return null;
        }

        @SideOnly(Side.CLIENT)
        private void performWorldSwitch() {
            Minecraft mc = Minecraft.getMinecraft();

            // 1. Выходим из мира
            if (mc.world != null) {
                mc.world.sendQuittingDisconnectingPacket();
                mc.loadWorld((WorldClient) null);

                // Останавливаем сервер
                if (mc.getIntegratedServer() != null) {
                    mc.getIntegratedServer().initiateShutdown();
                }
            }

            // 2. Главное меню
            mc.displayGuiScreen(new GuiMainMenu());

            // 3. Используем таймер для проверки состояния вместо отдельного потока
            // Ждем 1 секунду перед началом проверки
            new java.util.Timer().schedule(new java.util.TimerTask() {
                @Override
                public void run() {
                    checkServerAndLoadWorld();
                }
            }, 1000);
        }

        @SideOnly(Side.CLIENT)
        private void checkServerAndLoadWorld() {
            Minecraft mc = Minecraft.getMinecraft();

            // Проверяем в главном потоке Minecraft
            mc.addScheduledTask(() -> {
                boolean serverStopped = mc.getIntegratedServer() == null ||
                        mc.getIntegratedServer().isServerStopped();
                boolean worldUnloaded = mc.world == null;

                if (serverStopped && worldUnloaded) {
                    System.out.println("Сервер полностью остановлен, загружаем новый мир...");
                    try {
                        mc.launchIntegratedServer("the last survior", "Проклятье чёрного тумана", null);
                    } catch (Exception e) {
                        System.err.println("Ошибка загрузки мира: " + e.getMessage());
                        // В случае ошибки показываем сообщение
                        if (mc.player != null) {
                            mc.player.sendMessage(new TextComponentString(
                                    TextFormatting.RED + "Ошибка загрузки мира: " + e.getMessage()));
                        }
                    }
                } else {
                    // Если сервер еще не остановился, проверяем снова через 500ms
                    new java.util.Timer().schedule(new java.util.TimerTask() {
                        @Override
                        public void run() {
                            checkServerAndLoadWorld();
                        }
                    }, 500);
                }
            });
        }
    }
}